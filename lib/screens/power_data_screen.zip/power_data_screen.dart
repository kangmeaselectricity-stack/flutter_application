import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../database_service.dart';
import 'package:geolocator/geolocator.dart';

class PowerDataScreen extends StatefulWidget {
  const PowerDataScreen({super.key});

  @override
  State<PowerDataScreen> createState() => _PowerDataScreenState();
}

class _PowerDataScreenState extends State<PowerDataScreen> {
  List<Map<String, dynamic>> allPowerData = [];
  List<Map<String, dynamic>> filteredPowerData = [];
  bool isLoading = true;
  final TextEditingController searchController = TextEditingController();

  final Map<String, TextEditingController> controllers = {};
  final Map<String, FocusNode> focusNodes = {};
  final Map<String, double> calculatedUsage = {};
  String latestMonthDisplay = "";
  String _currentMode = "manual"; // manual, voice, camera

  // អថេរសម្រាប់គ្រប់គ្រង Voice Input
  final stt.SpeechToText _speech = stt.SpeechToText();
  String _listeningIdKey = "";

  @override
  void initState() {
    super.initState();
    _loadPowerData();
    _loadInputMode();
  }

  @override
  void dispose() {
    searchController.dispose();
    for (var c in controllers.values) {
      c.dispose();
    }
    for (var f in focusNodes.values) {
      f.dispose();
    }
    super.dispose();
  }

  Future<void> _loadInputMode() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _currentMode = prefs.getString('input_mode') ?? "manual";
    });
  }

  Future<void> _loadPowerData() async {
    try {
      setState(() => isLoading = true);
      final db = await DatabaseService().database;

      final tables = await db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='power_data';",
      );

      if (tables.isEmpty) {
        setState(() {
          allPowerData = [];
          filteredPowerData = [];
          isLoading = false;
        });
        return;
      }

      final List<Map<String, dynamic>> rawData = await db.query('power_data');
      latestMonthDisplay = "";

      controllers.clear();
      focusNodes.clear();
      calculatedUsage.clear();

      List<Map<String, dynamic>> mutableData = [];
      String lastValidVillage = "";
      String lastValidPole = "";

      for (int i = 0; i < rawData.length; i++) {
        var row = Map<String, dynamic>.from(rawData[i]);

        if (row['village'] != null &&
            row['village'].toString().trim().isNotEmpty) {
          lastValidVillage = row['village'].toString().trim();
        }
        if (row['pole'] != null && row['pole'].toString().trim().isNotEmpty) {
          lastValidPole = row['pole'].toString().trim();
        }

        row['display_village'] =
            row['village'] != null &&
                row['village'].toString().trim().isNotEmpty
            ? row['village']
            : lastValidVillage;
        row['display_pole'] =
            row['pole'] != null && row['pole'].toString().trim().isNotEmpty
            ? row['pole']
            : lastValidPole;

        String idKey = "row_${row['meter']}_$i";
        String currentNewVal = row['new_value']?.toString() ?? "";

        controllers[idKey] = TextEditingController(text: currentNewVal);
        focusNodes[idKey] = FocusNode();

        double ov = double.tryParse(row['old_value']?.toString() ?? '0') ?? 0;
        double nv = double.tryParse(currentNewVal) ?? 0;
        double m = double.tryParse(row['miti']?.toString() ?? '1') ?? 1.0;

        if (currentNewVal.isNotEmpty) {
          calculatedUsage[idKey] = _calculateUsageLogic(ov, nv, m);
        }

        row['_idKey'] = idKey;
        mutableData.add(row);
      }

      mutableData.sort(
        (a, b) => (a['display_pole']?.toString() ?? "").compareTo(
          b['display_pole']?.toString() ?? "",
        ),
      );

      setState(() {
        allPowerData = mutableData;
        filteredPowerData = mutableData;
        isLoading = false;
      });
    } catch (e) {
      debugPrint("❌ កំហុសក្នុងការទាញ power_data៖ $e");
      setState(() => isLoading = false);
    }
  }

  double _calculateUsageLogic(
    double oldValue,
    double newValue,
    double multiplier,
  ) {
    if (newValue >= oldValue) {
      return (newValue - oldValue) * multiplier;
    } else {
      return ((100000 - oldValue) + newValue) * multiplier;
    }
  }

  void _runFilter(String query) {
    if (query.isEmpty) {
      setState(() => filteredPowerData = allPowerData);
      return;
    }
    setState(() {
      filteredPowerData = allPowerData.where((row) {
        final village = row['display_village']?.toString().toLowerCase() ?? "";
        final meter = row['meter']?.toString().toLowerCase() ?? "";
        final code = row['code']?.toString().toLowerCase() ?? "";
        final pole = row['display_pole']?.toString().toLowerCase() ?? "";
        return village.contains(query.toLowerCase()) ||
            meter.contains(query.toLowerCase()) ||
            code.contains(query.toLowerCase()) ||
            pole.contains(query.toLowerCase());
      }).toList();
    });
  }

  // 🚀 មុខងារគណនាទីតាំងបម្លែងទៅជា UTM Coordinate ជាក់ស្តែងសម្រាប់ទឹកដីកម្ពុជា (Zone 48P)
  Future<String> _getUTMCoordinates() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return "48P (GPS មិនបានបើក)";
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return "48P (មិនមានសិទ្ធិ GPS)";
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return "48P (សិទ្ធិ GPS ត្រូវបានបិទ)";
      }

      // 🎯 កែសម្រួល៖ លុប forceAndroidLocationManager ចេញ ដើម្បីកុំឱ្យលោត Error undefined
      final LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10), // រង់ចាំ ១០ វិនាទី
      );

      Position? position;
      try {
        position = await Geolocator.getCurrentPosition(
          locationSettings: locationSettings,
        );
      } catch (_) {
        position = await Geolocator.getLastKnownPosition();
      }

      if (position == null) {
        return "48P GPS-Timeout";
      }

      double lat = position.latitude;
      double lng = position.longitude;

      int zone = 48;
      String band = "P";

      double laRad = lat * 0.01745329251;
      double k0 = 0.9996;
      double a = 6378137.0;
      double eccSquared = 0.00669437999;
      double longitudeOrigin = (zone * 6 - 183) * 0.01745329251;

      double eccPrimeSquared = (eccSquared) / (1 - eccSquared);
      double n = a / sqrt(1 - eccSquared * sin(laRad) * sin(laRad));
      double t = tan(laRad) * tan(laRad);
      double c = eccPrimeSquared * cos(laRad) * cos(laRad);
      double a1 = cos(laRad) * ((lng * 0.01745329251) - longitudeOrigin);

      double m =
          a *
          ((1 - eccSquared / 4 - 3 * eccSquared * eccSquared / 64) * laRad -
              (3 * eccSquared / 8 + 3 * eccSquared * eccSquared / 32) *
                  sin(2 * laRad) +
              (15 * eccSquared * eccSquared / 256) * sin(4 * laRad));

      double utmEasting =
          (k0 *
              n *
              (a1 +
                  (1 - t + c) * a1 * a1 * a1 / 6 +
                  (5 - 18 * t + t * t + 72 * c - 58 * eccPrimeSquared) *
                      a1 *
                      a1 *
                      a1 *
                      a1 *
                      a1 /
                      120)) +
          500000.0;

      double utmNorthing =
          (k0 *
          (m +
              n *
                  tan(laRad) *
                  (a1 * a1 / 2 +
                      (5 - t + 9 * c + 4 * c * c) * a1 * a1 * a1 * a1 / 24 +
                      (61 - 58 * t + t * t + 600 * c - 330 * eccPrimeSquared) *
                          a1 *
                          a1 *
                          a1 *
                          a1 *
                          a1 *
                          a1 /
                          720)));

      return "$zone$band ${utmEasting.toStringAsFixed(0)} ${utmNorthing.toStringAsFixed(0)}";
    } catch (e) {
      return "48P (Error GPS)";
    }
  }

  Future<void> _saveReading(
    String idKey,
    String value,
    Map<String, dynamic> row,
  ) async {
    try {
      final db = await DatabaseService().database;
      double? parsedNewValue = double.tryParse(value);

      String currentCode = row['code']?.toString() ?? "";
      String currentMeter = row['meter']?.toString().trim() ?? "";
      String currentMonth = row['month']?.toString().trim() ?? "";
      double oldVal =
          double.tryParse(row['old_value']?.toString() ?? '0') ?? 0.0;

      if (currentMeter.isEmpty) return;

      await db.update(
        'power_data',
        {'new_value': parsedNewValue ?? 0.0},
        where: 'code = ? AND meter = ? AND month = ? AND old_value = ?',
        whereArgs: [currentCode, currentMeter, currentMonth, oldVal],
      );

      double ov = oldVal;
      double m = double.tryParse(row['miti']?.toString() ?? '1') ?? 1.0;

      setState(() {
        row['new_value'] = value;
        if (value.isNotEmpty && parsedNewValue != null) {
          calculatedUsage[idKey] = _calculateUsageLogic(ov, parsedNewValue, m);
        } else {
          calculatedUsage.remove(idKey);
        }
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "💾 រក្សាទុកនាឡិកាស្ទង់ [ $currentMeter ] ចំនួន $value ជោគជ័យ!",
          ),
          backgroundColor: Colors.teal,
          duration: const Duration(milliseconds: 700),
        ),
      );
    } catch (e) {
      debugPrint("❌ កំហុសក្នុងការរក្សាទុក៖ $e");
    }
  }

  // 🚀 🎯 មុខងារ Voice Mode ពេញលេញសម្រាប់តារាងនាឡិកាមេ (កែសម្រួលដក const និងដូរ localeId)
  Future<void> _triggerVoiceRecognition(
    String idKey,
    Map<String, dynamic> row,
  ) async {
    FocusScope.of(context).unfocus(); // ដកក្តារចុចចេញជាមុនសិន

    bool available = await _speech.initialize();
    if (!available) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("❌ មិនអាចបើកប្រព័ន្ធស្រង់សំឡេងបានទេ")),
      );
      return;
    }

    setState(() {
      _listeningIdKey = idKey;
    });

    if (!mounted) return; // 🎯 ថែម mounted check ការពារ Warning context
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "🎙️ កំពុងស្តាប់សំឡេង... សូមនិយាយលេខអំណានថ្មីជាភាសាខ្មែរ",
        ),
        backgroundColor: Colors.redAccent,
        duration: Duration(seconds: 4),
      ),
    );

    _speech.listen(
      listenOptions: stt.SpeechListenOptions(
        // 🎯 លុបពាក្យ const ចេញ
        partialResults: false,
      ),
      localeId: "km_KH", // 🎯 លើក localeId មកដាក់នៅខាងក្រៅនេះវិញ
      onResult: (result) {
        if (result.recognizedWords.isNotEmpty) {
          String cleanNumber = result.recognizedWords.replaceAll(
            RegExp(r'[^0-9.]'),
            '',
          );

          if (cleanNumber.isNotEmpty) {
            setState(() {
              controllers[idKey]?.text = cleanNumber;
            });
            _saveReading(idKey, cleanNumber, row);
          }
        }
        setState(() => _listeningIdKey = "");
      },
    );
  }

  void _showHistoryDialog(Map<String, dynamic> row) {
    double historyDistribute =
        double.tryParse(row['distribute']?.toString() ?? '0.0') ?? 0.0;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.history, color: Colors.purple),
            const SizedBox(width: 8),
            const Text(
              "ប្រវត្តិប្រើប្រាស់",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "តំបន់៖ ${row['display_village'] ?? '---'}",
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 4),
            Text(
              "លេខនាឡិកាស្ទង់៖ ${row['meter'] ?? '---'}",
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 4),
            Text(
              "ខែស្រង់៖ ${row['month'] ?? '---'}",
              style: const TextStyle(fontSize: 14),
            ),
            const Divider(),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "ថាមពលខែមុន (distribute)៖",
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                Text(
                  "${historyDistribute.toStringAsFixed(2)} kWh",
                  style: const TextStyle(
                    color: Colors.purple,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("បិទ", style: TextStyle(color: Colors.teal)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          latestMonthDisplay.isNotEmpty
              ? "ស្រង់នាឡិកាស្ទង់មេ (ខែ៖ ${DateTime.now().toString().split(' ')[0]})"
              : "ស្រង់អំណាននាឡិកាស្ទង់មេ",
          style: const TextStyle(color: Colors.white, fontSize: 18),
        ),
        backgroundColor: Colors.teal,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "ស្វែងរកតំបន់, លេខបង្គោល ឬលេខនាឡិកាស្ទង់...",
                prefixIcon: const Icon(Icons.search, color: Colors.teal),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
              onChanged: _runFilter,
            ),
          ),
          Expanded(
            child: isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: Colors.teal),
                  )
                : filteredPowerData.isEmpty
                ? const Center(
                    child: Text("⚠️ គ្មានទិន្នន័យនាឡិកាមេសម្រាប់ខែនេះទេ"),
                  )
                : ListView.builder(
                    itemCount: filteredPowerData.length,
                    itemBuilder: (context, index) {
                      final row = filteredPowerData[index];
                      final idKey = row['_idKey'] ?? index.toString();

                      double oldVal =
                          double.tryParse(
                            row['old_value']?.toString() ?? '0',
                          ) ??
                          0.0;
                      double multiplier =
                          double.tryParse(row['miti']?.toString() ?? '1') ??
                          1.0;

                      // 🚀 🎯 គន្លឹះកំណត់រូបតំណាង Icon ប៊ូតុងផ្អែកលើ Mode បច្ចុប្បន្ន
                      Widget suffixIconWidget;
                      if (_currentMode == "voice") {
                        bool isThisListening = _listeningIdKey == idKey;
                        suffixIconWidget = IconButton(
                          icon: Icon(
                            Icons.mic,
                            color: isThisListening
                                ? Colors.red
                                : Colors.blueGrey,
                          ),
                          onPressed: () => _triggerVoiceRecognition(idKey, row),
                        );
                      } else if (_currentMode == "camera") {
                        suffixIconWidget = IconButton(
                          icon: const Icon(
                            Icons.camera_alt,
                            color: Colors.green,
                          ),
                          onPressed: () => _triggerCameraOCR(idKey, row),
                        );
                      } else {
                        suffixIconWidget = const Icon(
                          Icons.keyboard,
                          color: Colors.blue,
                        );
                      }

                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.pin_drop,
                                        color: Colors.indigo,
                                        size: 18,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        "បង្គោល៖ ${row['display_pole'] ?? '---'}",
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.indigo,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.teal.withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      "មេគុណ៖ $multiplier",
                                      style: const TextStyle(
                                        color: Colors.teal,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const Divider(),
                              Text(
                                "តំបន់៖ ${row['display_village'] ?? '---'}",
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                "អត្តលេខ៖ ${row['code'] ?? '---'}  |  នាឡិកាស្ទង់៖ ${row['meter'] ?? '---'}",
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          "អំណានចាស់",
                                          style: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12,
                                          ),
                                        ),
                                        Text(
                                          "$oldVal",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.blue,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 15),
                                  Expanded(
                                    flex: 2,
                                    child: TextField(
                                      controller: controllers[idKey],
                                      focusNode: focusNodes[idKey],
                                      keyboardType:
                                          const TextInputType.numberWithOptions(
                                            decimal: true,
                                          ),
                                      textInputAction: TextInputAction.done,
                                      decoration: InputDecoration(
                                        labelText: "វាយអំណានថ្មី",
                                        labelStyle: const TextStyle(
                                          fontSize: 13,
                                        ),
                                        border: const OutlineInputBorder(),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 10,
                                            ),
                                        suffixIcon: suffixIconWidget,
                                      ),
                                      onChanged: (val) {
                                        double? nv = double.tryParse(val);
                                        setState(() {
                                          if (val.isNotEmpty && nv != null) {
                                            calculatedUsage[idKey] =
                                                _calculateUsageLogic(
                                                  oldVal,
                                                  nv,
                                                  multiplier,
                                                );
                                          } else {
                                            calculatedUsage.remove(idKey);
                                          }
                                        });
                                        _saveReading(idKey, val, row);
                                      },
                                      onSubmitted: (val) =>
                                          _saveReading(idKey, val, row),
                                    ),
                                  ),
                                ],
                              ),
                              if (calculatedUsage.containsKey(idKey)) ...[
                                const SizedBox(height: 10),
                                GestureDetector(
                                  onTap: () => _showHistoryDialog(row),
                                  child: Container(
                                    width: double.infinity,
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.red.withValues(alpha: 0.05),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: Colors.red.withValues(
                                          alpha: 0.2,
                                        ),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            const Icon(
                                              Icons.bolt,
                                              color: Colors.red,
                                              size: 18,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              "ថាមពលសរុប៖ ${calculatedUsage[idKey]!.toStringAsFixed(2)} kWh",
                                              style: const TextStyle(
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                        const Icon(
                                          Icons.info_outline,
                                          color: Colors.red,
                                          size: 16,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // 🚀 មុខងារជំនួយ៖ គូរអក្សរ Drop Marker លើរូបភាពសម្រាប់នាឡិកាមេ (ដូច HomeScreen)
  Future<void> _drawWatermarkOnImage(
    File imageFile,
    Map<String, dynamic> row,
    String finalNumber,
  ) async {
    try {
      final Uint8List bytes = await imageFile.readAsBytes();
      final ui.Codec codec = await ui.instantiateImageCodec(bytes);
      final ui.FrameInfo frameInfo = await codec.getNextFrame();
      final ui.Image image = frameInfo.image;

      final ui.PictureRecorder recorder = ui.PictureRecorder();
      final Canvas canvas = Canvas(recorder);

      canvas.drawImage(image, Offset.zero, Paint());

      // ទាញយកអក្សរកូអរដោនេ UTM
      String utmCoords = await _getUTMCoordinates();

      String meterId = row['meter']?.toString() ?? 'មិនស្គាល់';
      String dateStr = DateTime.now().toString().split('.')[0];

      String textToDraw =
          "នាឡិកាមេ: $meterId\nអំណានថ្មី: $finalNumber\nUTM: $utmCoords\nថ្ងៃស្រង់: $dateStr";

      final ui.ParagraphBuilder builder = ui.ParagraphBuilder(
        ui.ParagraphStyle(
          textAlign: TextAlign.left,
          fontSize: (image.width * 0.038),
          fontWeight: FontWeight.bold,
        ),
      );

      // ១. គូរស្រមោលអក្សរពណ៌ខ្មៅនៅខាងក្រោម
      builder.pushStyle(ui.TextStyle(color: const ui.Color(0xFF000000)));
      builder.addText(textToDraw);

      // ២. គូរអក្សរពិតពណ៌លឿងចែសពីលើ
      builder.pushStyle(ui.TextStyle(color: const ui.Color(0xFFFFFF00)));

      final ui.Paragraph paragraph = builder.build();
      paragraph.layout(ui.ParagraphConstraints(width: image.width.toDouble()));

      // គូរទម្លាក់ទៅលើ Canvas ផ្នែកខាងក្រោមនៃរូបភាព
      canvas.drawParagraph(
        paragraph,
        Offset(24, image.height - paragraph.height - 35),
      );

      final ui.Picture picture = recorder.endRecording();
      final ui.Image imgWithWatermark = await picture.toImage(
        image.width,
        image.height,
      );
      final ByteData? byteData = await imgWithWatermark.toByteData(
        format: ui.ImageByteFormat.png,
      );

      if (byteData != null) {
        await imageFile.writeAsBytes(
          byteData.buffer.asUint8List(),
          flush: true,
        );
        debugPrint("✅ បោះត្រា Drop Marker លើរូបភាពនាឡិកាមេរួចរាល់!");
      }
    } catch (e) {
      debugPrint("កំហុសក្នុងការគូរត្រា៖ $e");
    }
  }

  // 🚀 🎯 មុខងារ Camera OCR ពេញលេញសម្រាប់តារាងនាឡិកាមេ (រក្សាលោតផ្ទាំងបណ្តែតឱ្យផ្ទៀងផ្ទាត់សិន)
  Future<void> _triggerCameraOCR(String idKey, Map<String, dynamic> row) async {
    FocusScope.of(context).unfocus(); // ដកក្តារចុចចេញជាមុនសិន

    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 60,
      maxWidth: 1920,
    );

    if (image == null) return;

    try {
      final inputImage = InputImage.fromFilePath(image.path);
      final textRecognizer = TextRecognizer(
        script: TextRecognitionScript.latin,
      );
      final RecognizedText recognizedText = await textRecognizer.processImage(
        inputImage,
      );

      String finalNumber = "";
      for (final block in recognizedText.blocks) {
        for (final line in block.lines) {
          String clean = line.text.replaceAll(RegExp(r'[^0-9.]'), '');
          if (clean.isNotEmpty) {
            finalNumber = clean;
            break;
          }
        }
        if (finalNumber.isNotEmpty) break;
      }

      textRecognizer.close();

      if (finalNumber.isNotEmpty) {
        setState(() {
          controllers[idKey]?.text = finalNumber;
        });

        // ១. រក្សាទុកទិន្នន័យអំណានចូល SQLite
        await _saveReading(idKey, finalNumber, row);

        // 🎯 ២. ហៅមុខងារបោះត្រា Watermark លើរូបភាពដែលទើបថតបាន
        await _drawWatermarkOnImage(File(image.path), row, finalNumber);

        if (!mounted) return;

        // 🎯 ៣. ហៅផ្ទាំងបង្ហាញ SnackBar ឬសួររក្សាទុករូបភាព
        // _askToSaveImageWithWatermark(
        //   context,
        //   File(image.path),
        //   row['meter']?.toString() ?? "Unknown",
        //   row['display_village']?.toString() ?? "Unknown",
        // );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("❌ ស្កេនមិនចំលេខទេ! សូមព្យាយាមម្ដងទៀត"),
            backgroundColor: Colors.orange,
          ),
        );
      }
    } catch (e) {
      debugPrint("កំហុសក្នុងការស្កេន OCR: $e");
    }
  }

  // // 🚀 មុខងារសួរនាំរក្សាទុករូបភាព (បើសិនជាបងមានមុខងារនេះនៅក្នុង HomeScreen អាចហៅប្រើបាន)
  // void _askToSaveImageWithWatermark(
  //   BuildContext context,
  //   File imageFile,
  //   String meter,
  //   String village,
  // ) {
  //   // បងអាចបន្ថែម Logic រក្សាទុករូបភាពទៅក្នុង Gallery ឬម៉ាស៊ីនត្រង់នេះ
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Text("📸 បានបោះត្រា UTM លើរូបភាពនាឡិកា $meter រួចរាល់!"),
  //       backgroundColor: Colors.teal,
  //     ),
  //   );
  // }
}
